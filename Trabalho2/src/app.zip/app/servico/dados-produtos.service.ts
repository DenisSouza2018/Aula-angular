export class dadosProdutos {
  constructor(
     public codigo: number,
     public nome: string,
     public valor: number,
     public quantidade: number,
     public desconto: number
  ){}
} 