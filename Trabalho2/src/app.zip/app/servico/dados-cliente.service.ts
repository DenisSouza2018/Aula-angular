export class dadosCliente {
  constructor(
     public nome: string,
     public email: string,
     public telefone: number
  ){}
} 