export class dadosNotaFiscal {
  constructor(
     public codigo: number,
     public descricao: string,
     public valor_unitario: number,
     public desconto: number,
     public quantidade: number
  ){}
} 